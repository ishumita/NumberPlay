import React, { Component } from 'react';
import './Game.css';


class StartScreen extends Component {

    render() {
        const { personalBest, previousScore, startGame } =  this.props;
        const hasPersonalBest = (personalBest && personalBest > 0) ? true : false;
        const hasPreviousScore = previousScore ? true : false;

        return(
            <screen>
                <h1 className="glow">Number Play</h1>
                <h3 className="game-aim">Aim of the game:</h3>
                <p className="game-desc">  Translate as many numbers into French as possible before the time runs out!
                 <h6>Don't use words like 'et' and symbols like '-' while translating</h6>    
                </p>
                <ul className="list-inline">
                            {(hasPersonalBest) && (
                                <li><h3 className="zero-bottom"><strong>Personal best:</strong> { personalBest }</h3></li>
                            )}
                            {(hasPreviousScore) && (
                                <li><h3 className="zero-bottom"><strong>Previous score:</strong> { previousScore }</h3></li>
                            )}
                        </ul>
               <div className="gamebutton"> <button className="game-btn" onClick={startGame}>Start</button></div>
                <h6 align="center">A game by Ishumita Mohan</h6>
            </screen>
        );
    };
};

export default StartScreen;