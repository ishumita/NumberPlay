import React, {Component} from 'react';
import './App.css';
import StartScreen from './StartScreen';
import GameScreen from './GameScreen';

import { EN, DE } from './config/languages'
import { modes, defaultMode } from './config/modes';
import { diacriticMap } from './config/diacritics';

//utils
import { capitalise, stripHTML, getRandomNumber } from './libs/utils';

//constants
const REMAINING_TIME = 60000;
const INCREMENT_TIME = 2000;

class App extends Component {

  constructor(props) {
    super(props);

    const DEFAULT_STATE = {
        gameStarted: false,
        currentMode: defaultMode,
        score: 0,
        previousScore: 0,
        personalBest: 0,
        remainingTime: REMAINING_TIME,
        currentNumber: ''

    }

    let SAVED_STATE = null;
    
    this.state = SAVED_STATE || DEFAULT_STATE;
  }

//starts the timer
 startTimer = () => {
    this.remainingTimer = setInterval(() => {
        let remainingTime = this.state.remainingTime - 1000;
        if(remainingTime < 0) {
            this.endGame();
        } else {
            this.setState({
                remainingTime
            })
        }
    }, 1000);
};
  
  startGame = () => {
    //alert("hi");
    let controls = {
      name: 'ishumita',
      
    }

    let number = this.getNewNumber();

    let newState = {
      currentNumber: number,
        gameStarted: true,
        score: 0,
        controls,
        
        
    }

    this.setState(newState, () => {
      this.startTimer(); 
   });
};

  /**
     * End game with fresh state (remembering previous score)
     * @return
     */
    endGame = () => {
      let newState = {
          gameStarted: false,
          previousScore: this.state.score,
          currentNumber: '',
          remainingTime: REMAINING_TIME
      };
      
      clearInterval(this.remainingTimer);
      alert("game over")
      this.setState(newState);
  };
/**
     * Replace special characters within a string to standard characters
     * @param  {String} string String to run function against
     * @return {String}        String with standard characters 
     */
    removeDiacritics = (string) => {
      diacriticMap.forEach(function(element, index) {
          string = string.replace(diacriticMap[index].letters, diacriticMap[index].base);
      });
      
      return string;
  };
/**
     * Handle what happens if a user answers the question correctly
     * @param  {String} answer User inputted answer
     * @return
     */
    handleSuccess = (answer) => {
      // Get new number
      let number = this.getNewNumber();
      // Increment score 
      let score = this.state.score + this.state.currentMode.multiplier;
      // Increment timer
      let remainingTime = this.state.remainingTime + INCREMENT_TIME;

      let newState = {
          personalBest: score > this.state.personalBest ? score : this.state.personalBest,
          answerAttempts: 0,
          currentNumber: number,
          score,
          remainingTime
      }

      this.setState(newState);
  };

  /**
   * Handle what happens if a user answers the question incorrectly
   * @return
   */
  handleFailure = () => {
      this.setState({
          answerAttempts: this.state.answerAttempts + 1
      });
  };

  /**
   * Determines whether a given response to a question is correct or incorrect
   * @param  {String} response The users response
   * @param  {Object} answer   The correct answer to compare the users response to
   * @return {Boolean}         Whether the answer is correct or incorrect
   */
  isCorrect = (response, answer) => {
      let responseSanitised = response.toLowerCase();
      let answerSanitised = answer.answerLanguage.toLowerCase();
      return (responseSanitised === answerSanitised || responseSanitised === this.removeDiacritics(answerSanitised)) ? true : false;
  };
    /**
     * Handle what happens when a user submits a response to a question
     * @param  {String} response The users response
     * @param  {Object} answer   The correct answer
     * @return
     */
    handleAnswer = (response, answer) => {
      let responseSanitised = stripHTML(response).replace(/\s+/g, '');

      if (this.isCorrect(responseSanitised, answer)) {
          this.handleSuccess(answer);
      } else if(response) {
          this.handleFailure();
      }
  };


  
    /**
     * Translate a number into textual form 
     * @param  {Number}  num       Number to translate
     * @param  {[type]}  lang      Language to reference
     * @param  {String}  direction Whether a number should be translated to 'Sixty nine' or 'Nine Sixty'
     * @param  {Boolean} space     Whether spaces should be placed between numbers, i.e. 'Sixty nine' or 'Sixtynine'
     * @return {String}            Translated number
     */
    translateNumber = (num, lang, direction = 'forwards', space = true) => {
      let whitespace = space ? ' ' : '';

      let convertMillions = function(num) {
          if (num >= 1000000) {
              return convertMillions(Math.floor(num / 1000000)) + whitespace + lang.million + whitespace + convertThousands(num % 1000000);
          } else {
              return convertThousands(num);
          }
      }

      let convertThousands = function(num) {
          if (num >= 1000) {
              return convertHundreds(Math.floor(num / 1000)) + whitespace + lang.thousand + whitespace + convertHundreds(num % 1000);
          } else {
              return convertHundreds(num);
          }
      }

      let convertHundreds = function(num) {
          if (num > 99) {
              if(direction === 'forwards') {  
                  return lang.ones[Math.floor(num / 100)] + whitespace + lang.hundred + whitespace + lang.join + whitespace + convertTens(num % 100);
              } else {
                  return lang.ones[Math.floor(num / 100)] + whitespace + lang.hundred + whitespace + convertTens(num % 100);
              }
          } else {
              return convertTens(num);
          }
      }

      let convertTens = function(num) {
          if (num < 10) return lang.ones[num];
          else if (num >= 10 && num < 20) {
              return lang.teens[num - 10];
          } else {
              if(direction === 'forwards') {  
                  return lang.tens[Math.floor(num / 10)] + whitespace + lang.ones[num % 10];
              } else {
                  if(num % 10 === 0) { 
                      // If number is divisible by ten
                      return lang.tens[Math.floor(num / 10)];
                  } else { 
                      return  lang.tens[Math.floor(num / 10)] + whitespace + whitespace + lang.ones[num % 10] ; 
                  }
              }
          }
      }

      let convert = function(num) {
          if (num == 0) return "zero";
          else if (num == 1) return lang.one[0];
          else return convertMillions(num);
      }

      return convert(num);
  };
    /**
     * Get new random number with translated values
     * @return {Object} A new random number object
     */
    getNewNumber = () => {
      let newNumber;
      let numberRange = this.state.currentMode.numberRange;

      let getNumber = function(){
          let number = getRandomNumber(1, numberRange);

          // If number is not the same as the current number
          if(number !== this.state.currentNumber.digits) {
              newNumber = {
                  digits: number,
                  questionLanguage: capitalise(this.translateNumber(number, EN, 'forwards', true)),
                  answerLanguage: capitalise(this.translateNumber(number, DE, 'backwards', false)),
              };
          } else {
              getNumber();
          } 
      }.bind(this);

      getNumber();

      return newNumber;
  };

  render(){

    let modeProps = {
      modes: modes,
      changeMode: this.handleGameModeChange,
      //currentMode: this.state.currentMode.name
  };
  
    let numberProps = {
      currentNumber: this.state.currentNumber,
      answer: this.handleAnswer,
      answerAttempts: this.state.answerAttempts
  };


    let scoreboardProps = {
      score: this.state.score,
      personalBest: this.state.personalBest,
      remainingTime: this.state.remainingTime
  };
  return (
    <app className="window">

      {(!this.state.gameStarted) && (
      <StartScreen startGame={ this.startGame }  previousScore={ this.state.previousScore } personalBest={ this.state.personalBest }/>
                )}

      {(this.state.gameStarted) && (
      <GameScreen controls={ this.state.controls }  modeProps={ modeProps } numberProps={ numberProps } scoreboardProps={ scoreboardProps }  />
        )}

    </app>
  );
}
}
export default App;


