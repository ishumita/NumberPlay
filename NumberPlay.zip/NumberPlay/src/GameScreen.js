import React, {Component} from 'react';
import ScoreBoard from './ScoreBoard';
import './Game.css';

class GameScreen extends Component {

        handleKeyUp = (event) => {
        let answer = this.props.numberProps.answer;
        if(event.which == 13) {
            answer(event.currentTarget.value, this.props.numberProps.currentNumber);
        }
    };

    render() {
        const { controls } = this.props;
        const { score, personalBest, remainingTime } = this.props.scoreboardProps;
       // const { modes, changeMode, currentMode } = this.props.modeProps;
        const { currentNumber, answer, answerAttempts } = this.props.numberProps;
        return (
            <screen>

            <ScoreBoard score={ score } personalBest={ personalBest } timer={ remainingTime } />
            <h2 className="digi">{ currentNumber.digits }</h2>
            <p className="langu">{ currentNumber.questionLanguage }</p>
            <input classname="input-box" ref="input" type="text" 
            onKeyUp={ this.handleKeyUp } placeholder="Translate the given number in french" 
         autofocus></input>
         
         <h4 className="desc">Note: Next number won't come unless you give correct answer. 
         Please erase your previous input text yourself. </h4>
            </screen>
        );

    }
    
}

export default GameScreen;