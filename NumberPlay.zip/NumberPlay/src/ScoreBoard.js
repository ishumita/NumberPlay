import React, { Component } from 'react';
import classNames from 'classnames';

class ScoreBoard extends Component {

    render() {
        const { score, personalBest, timer } = this.props;
        const timerClass = classNames({
            'flash-text': (timer / 1000) <= 10,
        });

        return (
            <div className="score-board">
                        <span className={ timerClass }>{ timer / 1000 }s</span>

                        <div ref="score" className="scores">
                   
                        <h3>Score</h3>
                        { score }

                </div>
                
            </div>
            )
}
}
export default ScoreBoard;