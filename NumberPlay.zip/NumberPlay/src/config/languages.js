export const EN = {
    'one' : ['one'],
    'ones': ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'],
    'tens': ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'],
    'teens': ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'],
    'million': 'million',
    'thousand': 'thousand',
    'hundred': 'hundred',
    'join': 'and',
};

export const DE = {
    'one' : ['un'],
    'ones': ['', 'un', 'deux', 'trios', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf'],
    'tens': ['', '', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante', 'soixante-dix', 'quatre-vingts', 'quatre-vingt-dix'],
    'teens': ['dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf'],
    'million': 'million',
    'thousand': 'mille',
    'hundred': 'cent',
    'join': 'et',
};

export default [EN, DE];
